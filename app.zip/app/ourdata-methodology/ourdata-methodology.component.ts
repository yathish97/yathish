import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourdata-methodology',
  templateUrl: './ourdata-methodology.component.html',
  styleUrls: ['./ourdata-methodology.component.scss']
})
export class OurdataMethodologyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
